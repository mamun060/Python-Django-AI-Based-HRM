### AI Based Human Resource Management System

### Start project- 
### Clone project
```
Step-01: pip install 
Step-02: connect Database credentials
Step-03: py manage.py makemigrations and py manage.py migrate
Step-04: py manage.py runserver
```

### Dependency version 
```
asgiref==3.8.1
Django==5.1.5
mysqlclient==2.2.7
python-decouple==3.8
sqlparse==0.5.3
tzdata==2025.1
```

### login credential
```
username: superadmin
password: hrm12345
email: almamun.dev21@gmail.com
````