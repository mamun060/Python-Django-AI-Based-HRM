from .Department_model import *
from .JobType_model import *
from .Designation_model import *
from .Employee_model import *