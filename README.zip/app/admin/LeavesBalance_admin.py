from django.contrib import admin
from app.models import LeaveBalance

admin.site.register(LeaveBalance)