from django.contrib import admin
from app.models import Reimbursement

admin.site.register(Reimbursement)