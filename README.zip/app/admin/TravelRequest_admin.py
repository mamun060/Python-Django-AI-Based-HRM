from django.contrib import admin
from app.models import TravelRequest

admin.site.register(TravelRequest)