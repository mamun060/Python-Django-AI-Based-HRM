from django.contrib import admin
from app.models import Leaves

admin.site.register(Leaves)